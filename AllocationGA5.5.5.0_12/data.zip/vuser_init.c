/* -------------------------------------------------------------------------------
	Script Title       : 
	Script Description : 
                        
                        
	Recorder Version   : 1096
   ------------------------------------------------------------------------------- */

vuser_init()
{

	web_url("10.125.2.182", 
		"URL=http://10.125.2.182/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		"Url=/branding/opti/os_bg.jpg", "Referer=http://10.125.2.182/branding/opti/stylesheet_public.css", ENDITEM, 
		"Url=/branding/opti/login.gif", "Referer=http://10.125.2.182/branding/opti/stylesheet_public.css", ENDITEM, 
		"Url=/branding/opti/bg_password.gif", "Referer=http://10.125.2.182/branding/opti/stylesheet_public.css", ENDITEM, 
		"Url=/images/common/loadingAnimation.gif", "Referer=http://10.125.2.182/bin-java/login?f=general/login.htm", ENDITEM, 
		"Url=/branding/opti/bg_username.gif", "Referer=http://10.125.2.182/branding/opti/stylesheet_public.css", ENDITEM, 
		LAST);

	return 0;
}